<div class="pages">
  <div data-page="projects" class="page no-toolbar no-navbar homepage">
    <div class="page-content">
    
     <div class="navbarpages">
       <div class="nav_left_logo"><a href="index.php"><img src="images/logo.png" alt="" title="" /></a></div>
       <div class="nav_right_button"><a href="menu.html"><img src="images/icons/white/menu.png" alt="" title="" /></a></div>
     </div>
     <div id="pages_maincontent">
              <div class="page_content"> 
              <div style="background-color: #000000; opacity: 0.6; color:#ffffff; padding:10px;">
              <div class="row">
              <h2 class="page_title">Thank You</h2>
              </div>
			<p>Thank you for your payment our sales team will get back to you within 24hrs.<br /><br />
            For queries contact us on the folowing:
            media@heartfeltonline.org<br />
            +263 772 629 118<br />
            <strong>God Bless you !!</strong>
              </p>
              
              </div> 
              
              </div>
              </div>
      
      </div>
      
      
    </div>
  </div>
</div>