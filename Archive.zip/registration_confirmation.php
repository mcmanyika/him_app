
<div class="pages">
  <div data-page="projects" class="page no-toolbar no-navbar homepage">
    <div class="page-content">
    
     <div class="navbarpages">
       <div class="nav_left_logo"><a href="index.php" class="external"><img src="images/logo.png" alt="" title="" /></a></div>
       <div class="nav_right_button"><a href="menu.html"><img src="images/icons/white/menu.png" alt="" title="" /></a></div>
     </div>
     <div id="pages_maincontent">
              <div class="page_content"> 
              <div style="background-color: #000000; opacity: 0.6; color:#ffffff; padding:10px;">
              <div class="row">
              <h2 class="page_title">Thank You</h2>
              </div>
              	Your registration has been successful, enjoy our free music and sermons from Apostle T and Pastor C Vutabwashe. To access our <strong>Premuim</strong> streams  <a href="packages.html">subscribe here!!</a>
            
              </div> 
              
              </div>
              </div>
      
      </div>
      
      
    </div>
  </div>
</div>