<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<link rel="apple-touch-icon" href="images/apple-touch-icon.png" />
<link rel="apple-touch-startup-image" media="(device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2)" href="apple-touch-startup-image-640x1096.png">
<title>Heartfelt International Ministries</title>
<link rel="stylesheet" href="css/framework7.css">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="css/colors/blue.css">
<link type="text/css" rel="stylesheet" href="css/swipebox.css" />
<link type="text/css" rel="stylesheet" href="css/animations.css" />
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300,700,900' rel='stylesheet' type='text/css'>
</head>
<body id="mobile_wrap">
<div class="pages">
  <div data-page="projects" class="page no-toolbar no-navbar homepage">
    <div class="page-content">
    
     <div class="navbarpages">
       <div class="nav_left_logo"><a href="index.php"><img src="images/logo.png" alt="" title="" /></a></div>
       <div class="nav_right_button">
       <a href="menu.html"><img src="images/icons/white/menu.png" alt="" title="" /></a>
       <a href="#" data-panel="right" class="open-panel"><img src="images/icons/white/search.png" alt="" title="" /></a>
       </div>
     </div>
     <div id="pages_maincontent">
       <div class="page_content">
            <div class="blog-posts" style="background-color: #000000; opacity: 0.6;">
             <h2 class="page_title">Our Location</h2>
              <div class="contact_info" style="color:#ffffff; padding:5px;">
              <h2>Address</h2>
               02 Sandy Lane,  Ashdown Park , <br/> Harare, Zimbabwe<br />
              Email: media@heartfeltonline.org <br />
              Mobile: +263 777 459 999
              </div> 
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3799.036253923444!2d30.981087814881995!3d-17.78999318783848!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1931a8aa6bdf70bf%3A0xb4ebf8a08826b07c!2sSandy+Ln%2C+Harare!5e0!3m2!1sen!2szw!4v1490131909815" width="100%" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>         
              
              <div class="clear"></div>  
              
            </div>
      
      </div>
      
      </div>
      
      
    </div>
  </div>
</div>


  </body>
</html>
